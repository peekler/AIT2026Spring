//
//  TodoItem.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//

struct TodoItem: Identifiable {
    var id: String
    var name: String
    var isChecked: Bool
}
