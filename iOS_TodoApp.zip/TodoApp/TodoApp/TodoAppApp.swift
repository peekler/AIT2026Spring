//
//  TodoAppApp.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//

import SwiftUI


@main
struct TodoAppApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                TodoListView(viewModel: TodoListView.ViewModel(todos: []))
            }
        }
    }
}
