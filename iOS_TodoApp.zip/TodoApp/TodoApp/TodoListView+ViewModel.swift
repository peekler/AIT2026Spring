//
//  TodoListView+ViewModel.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//
import SwiftUI

extension TodoListView {
    final class ViewModel: ObservableObject {
        
        @Published var todos: [TodoItem]
        @Published var todoName = ""

        init(todos: [TodoItem]) {
            self.todos = todos
        }

        func addTodo() {
            self.todos.append(TodoItem(id: UUID().uuidString, name: todoName, isChecked: false))
            self.todoName = ""
        }

        func delete(at offsets: IndexSet) {
            todos.remove(atOffsets: offsets)
        }
    }
}
