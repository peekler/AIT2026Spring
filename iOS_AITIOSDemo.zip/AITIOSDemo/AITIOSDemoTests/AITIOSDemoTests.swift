//
//  AITIOSDemoTests.swift
//  AITIOSDemoTests
//
//  Created by Peter Ekler on 2026. 05. 06..
//

import Testing
@testable import AITIOSDemo

struct AITIOSDemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
