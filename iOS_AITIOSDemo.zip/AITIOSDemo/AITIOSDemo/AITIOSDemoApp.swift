//
//  AITIOSDemoApp.swift
//  AITIOSDemo
//
//  Created by Peter Ekler on 2026. 05. 06..
//

import SwiftUI

@main
struct AITIOSDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
