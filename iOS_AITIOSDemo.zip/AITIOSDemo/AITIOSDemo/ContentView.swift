//
//  ContentView.swift
//  AITIOSDemo
//
//  Created by Peter Ekler on 2026. 05. 06..
//

import SwiftUI

struct ContentView: View {
    
    @State private var currentTime: String = ""
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world! \(currentTime)")
            Button("Show time") {
                currentTime = "Current time: \(Date().description)"
            //}.buttonStyle(.borderedProminent)
            }.buttonStyle(GrowingButton())
        }
        .padding()
    }
}


struct GrowingButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(.green.opacity(0.4))
            .foregroundStyle(.white)
            .clipShape(Capsule())
            .scaleEffect(configuration.isPressed ? 1.2 : 1)
            .animation(.easeOut(duration: 0.2), value: configuration.isPressed)
    }
}


#Preview {
    ContentView()
}
