//
//  ContentView.swift
//  AITDemoTime
//
//  Created by Peter Ekler on 2026. 02. 02..
//

import SwiftUI

struct ContentView: View {
    @State private var currentTime: String = ""
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)

            Button("Current time") {
                            let formatter = DateFormatter()
                            formatter.dateFormat = "HH:mm:ss"
                            let timeString = formatter.string(from: Date())
                            //currentTime = "Current Time: \(Date().description)"
                            currentTime = "Current: \(timeString)"
            }.buttonStyle(.borderedProminent)

            Text("Hello, world!\(currentTime)")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
