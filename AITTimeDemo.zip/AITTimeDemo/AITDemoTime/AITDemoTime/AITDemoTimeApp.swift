//
//  AITDemoTimeApp.swift
//  AITDemoTime
//
//  Created by Peter Ekler on 2026. 02. 02..
//

import SwiftUI

@main
struct AITDemoTimeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
